    <footer class="footer">
      <div class="container">
        <p class="text-muted">Create By : admin PT. RANGGA JAYA ABADI</p>
      </div>
    </footer>


 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>
