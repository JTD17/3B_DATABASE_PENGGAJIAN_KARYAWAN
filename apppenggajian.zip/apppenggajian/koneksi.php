<?php
$konek = mysqli_connect("localhost","root","rangga9807","penggajian_karyawan");
if (!$konek){
	echo "koneksi ke mysql gagal...";

}
?>