
<?php include "header.php"; ?>
    <!-- Begin page content -->
    <div class="container">
     <div class="panel panel-primary">
      <div class="panel panel-heading">
        <h3 class="panel-title">Halaman Utama Aplikasi Penggajian</h3>
    </div>
    <div class = "panel-body">
      <img src="assets/img/background_belakang.png" alt="Gambar" class= "img-thumbnail" width="100%">
  </div>
    </div>
    </div>

    <?php include "footer.php"; ?>

